
python 1.py $@
