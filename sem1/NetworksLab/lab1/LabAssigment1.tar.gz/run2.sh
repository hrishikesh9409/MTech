

python 2.py $@
