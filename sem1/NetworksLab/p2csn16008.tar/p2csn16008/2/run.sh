python2 TcpServer.py $@
