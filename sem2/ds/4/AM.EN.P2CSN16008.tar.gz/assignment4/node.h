#pragma once 

#include <iostream>

struct node{
	int data;
	node* next;
};