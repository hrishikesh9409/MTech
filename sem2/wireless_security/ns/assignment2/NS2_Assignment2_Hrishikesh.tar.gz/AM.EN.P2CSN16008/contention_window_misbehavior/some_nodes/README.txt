The mac-802_11.h has been modified to set specific CWMin and CWMax for misbehaving nodes identified by _node_type_
_node_type_ is set in the tcl file when the node is created.
_CWMin_ and _CWMax_ are also set in tcl for the misbehaving node.
(Line number 235)
