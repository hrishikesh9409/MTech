run ./run.sh file

to make changes to what site needs to be spoofed and all that modify the command in the run.sh file