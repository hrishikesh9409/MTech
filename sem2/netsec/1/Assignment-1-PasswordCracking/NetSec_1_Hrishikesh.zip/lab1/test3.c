/*
	BY 																		LAB	1
	Hrishikesh N 									Program to unshadow given password file and a shadow file
	AM.EN.P2CSN16008
*/

#include <stdio.h>
#include <string.h>   //standard string operations 

int main(int argc, char* argv[])	//passing parameters through commandline arguments
{
  char c[256];  /* declare a char array to store contents while reading from a file*/
  FILE *file;  /* declare a FILE pointers */
  file = fopen(argv[1], "r");	//Second file
  char *p;	/*	2 char* pointers p and q to read from file 	*/

  while(fgets(c, sizeof(c), file) != NULL){    
      p = strtok(c, ":");
      p = strtok(NULL, ":");
      p = strtok(NULL, ":");
      printf("%s:", p);
  }
  fclose(file);		//close file and free buffers i.e. file pointers
  return 0;
}